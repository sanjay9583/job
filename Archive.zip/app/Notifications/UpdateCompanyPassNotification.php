<?php

namespace App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class UpdateCompanyPassNotification extends Notification implements ShouldQueue
{
    use Queueable;

    public $data;

    /**
     * Create a new notification instance.
     *
     * @return void
     */
    public function __construct($data)
    {
        $this->data = $data;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function via($notifiable)
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return \Illuminate\Notifications\Messages\MailMessage
     */
    public function toMail($notifiable)
    {
        $type = "update_company_pass";
        $formatted_mail_data = getFormattedTextByType($type, [
            "user_name" => $this->data[0]->name,
            "user_email" => $this->data[0]->email,
            "password" => $this->data[1],
            "account_type" => $this->data[2]
        ]);
        $subject = $formatted_mail_data["subject"];
        $message = $formatted_mail_data["message"];

        return (new MailMessage)
            ->subject($subject)
            ->line($message)
            ->action('Login', url('login'))
            ->view("mails.email-template", ["content" => $message]);
    }

    /**
     * Get the array representation of the notification.
     *
     * @param  mixed  $notifiable
     * @return array
     */
    public function toArray($notifiable)
    {
        return [
            //
        ];
    }
}
