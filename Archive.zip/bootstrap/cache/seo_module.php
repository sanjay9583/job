<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Seo\\Providers\\SeoServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Seo\\Providers\\SeoServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);