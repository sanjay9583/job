<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Blog\\Providers\\BlogServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Blog\\Providers\\BlogServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);